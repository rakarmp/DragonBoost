## v1.3

- Fix Double Process ro.sys.fw.bg_apps_limit
- Multithread & Hyperthread true
- Delete Dalvik Settings (Not Work)

## v1.2

- Set Touch Boost
- Force GPU Touch RenderRender
- Google Service Reduce Drain Tweaks
- CPU Perf

## v1.1

- Add Ram Management
- I/O Optimization RAM
- VM Setting
- OOM (Out Of Memory)
- Entropy
- Optimization Activity Manager
- Low Memory Killer

## v1.0

- Initial Release
